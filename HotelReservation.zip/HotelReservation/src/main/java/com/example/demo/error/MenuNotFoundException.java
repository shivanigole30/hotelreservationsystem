package com.example.demo.error;

public class MenuNotFoundException extends Exception{

	public MenuNotFoundException(String message) {
		super(message);
	}
}
