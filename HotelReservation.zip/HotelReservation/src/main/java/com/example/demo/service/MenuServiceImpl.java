package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.entity.Menu;
import com.example.demo.error.CustomerNotFoundException;
import com.example.demo.error.MenuNotFoundException;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.MenuRepository;

@Service
public class MenuServiceImpl implements MenuService{

	@Autowired
	private MenuRepository menuRepository;
	@Autowired
	private CustomerRepository customerRepository;
	@Override
	public Menu addMenu(@Valid Menu menu) {
		// TODO Auto-generated method stub
		return menuRepository.save(menu);
	}
	@Override
	public List<Menu> getAllMenu() {
		// TODO Auto-generated method stub
		return menuRepository.findAll();
	}
	@Override
	public Menu findByMenuName(String menuname) throws MenuNotFoundException {
		// TODO Auto-generated method stub
		Optional<Menu> menu=menuRepository.findByMenuName(menuname);
		if(menu==null) {
			throw new MenuNotFoundException("Menu not found");
			
		}
		return menu.get();
	}
	@Override
	public Menu choosedMenuByCustomer(Integer menuid, Integer cid) throws CustomerNotFoundException, MenuNotFoundException {
		// TODO Auto-generated method stub
		Optional<Customer> customer=customerRepository.findById(cid);
		Optional<Menu> menu=menuRepository.findById(menuid);
		if(!customer.isPresent()) {
			throw new CustomerNotFoundException("customer not found");
			
		}else if(!menu.isPresent()) {
			throw new MenuNotFoundException("menu not found");
		}else {
			Customer customer1=customerRepository.findById(cid).get();
			Menu menu1=menuRepository.findById(menuid).get();
			menu1.choosedMenu(customer1);
			return menuRepository.save(menu1);
		}
	}
	
	
	
	

}
